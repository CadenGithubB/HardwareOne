# Revision 16 — separate enclosure parts

Import each STL as a separate object, in millimeters, at 100% scale. The parts
have been individually positioned on Z=0; their import positions are not the
assembled positions. Print one of each file.

| Part | Supplied orientation | Notes |
|---|---|---|
| Base | Floor down | Inspect supports under internal shelves and USB openings. |
| Lid | Exterior face down | Insert pockets face upward. Inspect support needs around the display opening and R2 edge. |
| Midframe | Flat underside down | Includes the battery cable opening and connected wire channel. |
| Button strip | Actuator stems down | Requires support under the arms and anchor bar; inspect the small contact areas before printing. |

Use the slicer's layer preview to confirm that thin walls and button arms are
actually generated with your nozzle and extrusion width. These are generic STL
files, not printer-specific profiles or G-code. Printed fit, material strength,
button return force, and hardware clearances still need a physical trial.

## Battery cable

The plug opening near J25 is **7 × 8 mm**, with R1 corners. The user measured
the plug width as 5 mm. A **3 mm wide through-slot** connects the opening to
a flared entry above the battery's front-right corner. The entry cutter extends
past the plate edge to avoid leaving a detached fragment beside the case post.

Orient the battery so its lead corner is toward case XY **(73.5,6)**. Bring the
lead up through that corner relief, turn it inward over the battery, and lay
it in the channel toward the plug opening. Feed the plug before installing the
PCB and connect it to J25. Keep slack away from the wheel and screw heads.
Do not trap wires in the 0.5 mm space between the battery and the solid plate.
The route has nominal room for 1–2 mm insulated leads; the actual wire diameter,
plug thickness, bend radius, and exit height have not been measured. A lead
emerging low on the battery's side may need a different routing arrangement.

The base floor and the four case-screw wells remain closed. The battery and
case hardware positions are unchanged. The front PCB seat moves 4 mm inward
along X to clear the cable channel.

## Hardware and assembly

- Four M2 × 8 mm nylon case screws and two M2 × 8 mm nylon midframe screws.
- Six heat-set inserts, outside diameter 3 mm and length 3.2 mm.
- Printed insert pilots are 2.7 mm with a 3.1 mm entry. Verify the fit with your
  insert and material before heat-setting all six. Fit inserts with the battery
  and electronics removed.
- The separate PCB mounting pilot remains 1.2 mm for a provisional M1.6 screw;
  it is not one of the six M2 insert mounts.
- Screen retention, the button strip anchors, and PCB seating still need the
  physical fit check described in the parent README.

## Export checks

All four final files are single closed meshes with consistent winding and
positive volume. Checks found no zero-area triangles, duplicate triangles,
boundary edges, or nonmanifold edges. `export-manifest.json` records dimensions,
orientation transforms, hashes, and export details. Base triangulation and
button-strip degenerate faces were cleaned without changing their surfaces.
These checks establish mesh integrity, not a tested hardware fit.
