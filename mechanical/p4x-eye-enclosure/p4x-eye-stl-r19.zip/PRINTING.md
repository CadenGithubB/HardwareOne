# Revision 19 — prototype enclosure parts

**Not ready for JLC3DP production or its requested insert installation.** The
current thin walls, locating features and M2 insert layout require a separate
manufacturing decision. See the enclosure folder’s `JLC3DP_REVIEW.md` before
placing an order; mesh validity alone is not manufacturing approval.

Import each STL as a separate object, in millimeters, at 100% scale. The parts
have been positioned on Z=0; their import positions are not the assembled
positions. All five final STL files passed the export checks below.

**Print the new lid, button strip and separate power slider together.** Revision
18 base and midframe geometry is unchanged and those parts can be reused.
There are five parts in the complete revision 19 set. Previous files and
quotation drawings are retained separately.

| Part | Supplied orientation | Notes |
|---|---|---|
| Base | Floor down | Inspect supports under internal shelves and USB openings. |
| Lid | Exterior face down | Insert pockets face upward. Inspect support needs around the display opening, receiver pockets and R2 edge. |
| Midframe | Flat underside down | Includes the open front-right cable bay and three upward locating keys. |
| Button strip | Actuator stems down | Includes power-slider retainer shelf; inspect supports under shelf, arms and bar. |
| Power slider | Nub face down; socket upward | New separate moving part. Preserve flange, nub and socket dimensions; remove supports without blocking the socket. |

Use the slicer's layer preview to confirm that thin walls and button arms are
actually generated with your nozzle and extrusion width. These are generic STL
files, not printer-specific profiles or G-code. Printed fit, material strength,
button return force, and hardware clearances still need a physical trial.

## Lid alignment and screen cable

The midframe carries three 8 x 1.5 mm locating keys that rise 2.5 mm above its
plate. Chamfered tips enter blind pockets in the lid with 0.2 mm nominal
clearance per side and 0.3 mm above each key. Fit the lid and frame together
before installing electronics. The lid should lower vertically and seat freely;
the case screws secure it after the keys have located it. Do not draw a binding
key into its pocket by tightening the screws.

The LCD flex relief is now **24 x 6.35 mm**, with R0.6 corners and 0.5 mm more
upward clearance than revision 16. It retains a 1 mm skin beneath the exterior
face. Check the cable bend with the screen seated; the LCD pocket and flush
seat height are unchanged.

## Battery cable and power access

The midframe's former small opening and wire slot are replaced by **one open
front-right bay** with R1 corners. Its cutter spans X64.5-81, Y-1-28.65 and
opens through the front and right plate edges, removing the thin strips.
Approximately 91.3% of the battery's XY footprint remains under the plate.
The base floor and all four case-screw wells stay closed.

Orient the battery's lead corner toward case XY **(73.5,6)** and route the
lead upward through the open bay to J25. Keep slack inside the case and clear
of screws, the wheel and PCB supports. Do not trap wires in the 0.5 mm gap
beneath the remaining plate. The front PCB seat is now X60-63, with its
previous Y and Z placement retained.

Revision 19 replaces the exposed SW7 opening with a **separate captive power
slider**. Its nub is 6 x 3.8 mm and projects 1 mm above the lid. A 14 x 7.6 mm
flange covers the 9 x 4.4 mm running slot from underneath. An integral shelf on
the button strip captures that flange using the strip's existing two screws.
The socket is 2 mm square with a 2.4 mm entry, sized around the nominal
1.5 mm-square switch handle. The flange overlaps the slot throughout its
3 mm nominal travel; this is not a waterproof seal.

With the lid separate, insert the cap from inside and fit the button strip to
capture it. Check free motion. When lowering the cover, align the cap socket
with the original SW7 handle. Do not force the cap onto the switch or glue the
moving slider. Check both switch positions and the cap's full travel.

There is 0.3 mm nominal Y clearance at the running guides, and 0.2 mm above
and below the flange at its nominal height. The socket has only 0.25 mm per
side around the nominal handle, so lateral handle contact can occur before
the guide limits movement. The retainer carries intended downward loads; it
does not isolate all sideways loads. Keep the slot, guides, retainer
opening and socket free of clear-coat buildup and adhesive; clear gloss is
for exterior cosmetic surfaces. The switch drawing and BOM disagree on handle
height (2 versus 2.5 mm), so actual engagement and the shelf/bridge load path
need a fit prototype. The strip retains anchors at (63,19) and (63,36).

## Hardware and assembly

- Four M2 × 8 mm nylon case screws and two M2 × 8 mm nylon midframe screws.
- Six heat-set inserts, outside diameter 3 mm and length 3.2 mm.
- Printed insert pilots are 2.7 mm with a 3.1 mm entry. Verify the fit with your
  insert and material before heat-setting all six. Fit inserts with the battery
  and electronics removed.
- The separate PCB mounting pilot remains 1.2 mm for a provisional M1.6 screw;
  it is not one of the six M2 insert mounts.
- Screen retention, the button strip anchors, and PCB seating still need the
  physical fit check described in the parent README.

## Export checks

All five final revision 19 meshes are watertight with consistent winding,
positive volume and one closed component each. There are no degenerate or
duplicate triangles, boundary edges or nonmanifold edges. Each mesh starts
at minimum X, Y and Z of zero. `export-manifest.json` records dimensions,
orientation transforms, source/mesh hashes and individual check results.

Base and midframe hashes match revision 18. The base retains its prior cleanup
of five zero-area faces using existing vertices without moving coordinates;
the frame is unchanged. Lid, strip and power slider are clean revision 19
CGAL exports. All five output hashes were checked against the manifest.

Four-page drawing text and dimensions were independently checked against the
CAD and manifest. All four rendered PDF pages passed visual inspection.
Numerical viewer checks passed with 73,560 finite faces, 64 simple R2 rings,
and cap travel, overlap and retainer checks. Power switch and Button mechanism
browser views were inspected without reported console warnings or errors.
Physical fit, operating forces, supplier acceptance and support settings remain
unverified. The supplier
may reorient parts for resin supports; preserve the socket and guide surfaces.
