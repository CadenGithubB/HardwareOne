# Revision 18 — prototype enclosure parts

**Not ready for JLC3DP production or its requested insert installation.** The
current thin walls, locating features and M2 insert layout require a separate
manufacturing decision. See the enclosure folder’s `JLC3DP_REVIEW.md` before
placing an order; mesh validity alone is not manufacturing approval.

Import each STL as a separate object, in millimeters, at 100% scale. The parts
have been individually positioned on Z=0; their import positions are not the
assembled positions. All four final STL meshes passed the export checks below.

**Reprint the lid, midframe and button strip together.** The base geometry is
unchanged from revision 17, so an existing base can be reused. Prior revision
17 STL files, ZIP and quotation drawing are retained separately.

| Part | Supplied orientation | Notes |
|---|---|---|
| Base | Floor down | Inspect supports under internal shelves and USB openings. |
| Lid | Exterior face down | Insert pockets face upward. Inspect support needs around the display opening, receiver pockets and R2 edge. |
| Midframe | Flat underside down | Includes the open front-right cable bay and three upward locating keys. |
| Button strip | Actuator stems down | Shortened anchor bar; front fixing moved to (63,19). Inspect supports below arms and bar. |

Use the slicer's layer preview to confirm that thin walls and button arms are
actually generated with your nozzle and extrusion width. These are generic STL
files, not printer-specific profiles or G-code. Printed fit, material strength,
button return force, and hardware clearances still need a physical trial.

## Lid alignment and screen cable

The midframe carries three 8 x 1.5 mm locating keys that rise 2.5 mm above its
plate. Chamfered tips enter blind pockets in the lid with 0.2 mm nominal
clearance per side and 0.3 mm above each key. Fit the lid and frame together
before installing electronics. The lid should lower vertically and seat freely;
the case screws secure it after the keys have located it. Do not draw a binding
key into its pocket by tightening the screws.

The LCD flex relief is now **24 x 6.35 mm**, with R0.6 corners and 0.5 mm more
upward clearance than revision 16. It retains a 1 mm skin beneath the exterior
face. Check the cable bend with the screen seated; the LCD pocket and flush
seat height are unchanged.

## Battery cable and power access

The midframe's former small opening and wire slot are replaced by **one open
front-right bay** with R1 corners. Its cutter spans X64.5-81, Y-1-28.65 and
opens through the front and right plate edges, removing the thin strips.
Approximately 91.3% of the battery's XY footprint remains under the plate.
The base floor and all four case-screw wells stay closed.

Orient the battery's lead corner toward case XY **(73.5,6)** and route the
lead upward through the open bay to J25. Keep slack inside the case and clear
of screws, the wheel and PCB supports. Do not trap wires in the 0.5 mm gap
beneath the remaining plate. The front PCB seat is now X60-63, with its
previous Y and Z placement retained.

SW7 has a **12 x 5 mm R1 lid opening**, widening to a **14 x 7 mm R2 mouth**
with an outward bevel. Reach the original power slider with a fingernail;
there is no extra actuator part. The drawing and BOM disagree on handle
height (2 versus 2.5 mm), so check actual reach and the full 2 mm slider travel
before ordering or final assembly. The front button-strip anchor moved from
(63,14) to **(63,19)**, and its bar now spans Y16.5-38. Use the revision 18 lid
and strip together.

## Hardware and assembly

- Four M2 × 8 mm nylon case screws and two M2 × 8 mm nylon midframe screws.
- Six heat-set inserts, outside diameter 3 mm and length 3.2 mm.
- Printed insert pilots are 2.7 mm with a 3.1 mm entry. Verify the fit with your
  insert and material before heat-setting all six. Fit inserts with the battery
  and electronics removed.
- The separate PCB mounting pilot remains 1.2 mm for a provisional M1.6 screw;
  it is not one of the six M2 insert mounts.
- Screen retention, the button strip anchors, and PCB seating still need the
  physical fit check described in the parent README.

## Export checks

All four final revision 18 meshes are watertight, have consistent winding and
positive volume, and each has one closed component. Checks found no degenerate
or duplicate triangles, boundary edges or nonmanifold edges. Minimum X, Y and
Z are zero for every part. `export-manifest.json` records measured sizes,
orientation transforms, source and mesh hashes, and per-part results.

The unchanged base matches its revision 17 mesh hash. Its prior cleanup
retriangulated five zero-area faces using existing vertices without moving
coordinates. Lid, midframe and strip use clean revision 18 CGAL exports.
Revision 18 numerical viewer checks passed with 73,125 finite faces and
64 simple R2 rings. The Power switch and Midframe detail browser views were
inspected without reported console warnings or errors. All three quotation
PDF pages passed rendered visual inspection; their dimensions and file hashes
were independently checked. Physical fit, supplier acceptance and slicer support
settings remain unverified. The manufacturer remains
undecided; Protolabs was ruled out by the user on price.
