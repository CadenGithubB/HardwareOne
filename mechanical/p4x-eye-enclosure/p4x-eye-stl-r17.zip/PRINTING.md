# Revision 17 — prototype enclosure parts

**Not ready for JLC3DP production or its requested insert installation.** The
current thin walls, locating features and M2 insert layout require a separate
manufacturing decision. See the enclosure folder’s `JLC3DP_REVIEW.md` before
placing an order; mesh validity alone is not manufacturing approval.

Import each STL as a separate object, in millimeters, at 100% scale. The parts
have been individually positioned on Z=0; their import positions are not the
assembled positions. All four final STL meshes passed the export checks below.

**Reprint the lid and midframe together.** The base and button-strip geometry
is unchanged from revision 16, so those existing parts can be reused. The
revision 16 STL files and ZIP are retained separately.

| Part | Supplied orientation | Notes |
|---|---|---|
| Base | Floor down | Inspect supports under internal shelves and USB openings. |
| Lid | Exterior face down | Insert pockets face upward. Inspect support needs around the display opening, receiver pockets and R2 edge. |
| Midframe | Flat underside down | Includes the battery cable route and three upward locating keys. |
| Button strip | Actuator stems down | Requires support under the arms and anchor bar; inspect the small contact areas before printing. |

Use the slicer's layer preview to confirm that thin walls and button arms are
actually generated with your nozzle and extrusion width. These are generic STL
files, not printer-specific profiles or G-code. Printed fit, material strength,
button return force, and hardware clearances still need a physical trial.

## Lid alignment and screen cable

The midframe carries three 8 x 1.5 mm locating keys that rise 2.5 mm above its
plate. Chamfered tips enter blind pockets in the lid with 0.2 mm nominal
clearance per side and 0.3 mm above each key. Fit the lid and frame together
before installing electronics. The lid should lower vertically and seat freely;
the case screws secure it after the keys have located it. Do not draw a binding
key into its pocket by tightening the screws.

The LCD flex relief is now **24 x 6.35 mm**, with R0.6 corners and 0.5 mm more
upward clearance than revision 16. It retains a 1 mm skin beneath the exterior
face. Check the cable bend with the screen seated; the LCD pocket and flush
seat height are unchanged.

## Battery cable

The plug opening near J25 is **7 × 8 mm**, with R1 corners. The user measured
the plug width as 5 mm. A **3 mm wide through-slot** connects the opening to
a flared entry above the battery's front-right corner. The entry cutter extends
past the plate edge to avoid leaving a detached fragment beside the case post.

Orient the battery so its lead corner is toward case XY **(73.5,6)**. Bring the
lead up through that corner relief, turn it inward over the battery, and lay
it in the channel toward the plug opening. Feed the plug before installing the
PCB and connect it to J25. Keep slack away from the wheel and screw heads.
Do not trap wires in the 0.5 mm space between the battery and the solid plate.
The route has nominal room for 1–2 mm insulated leads; the actual wire diameter,
plug thickness, bend radius, and exit height have not been measured. A lead
emerging low on the battery's side may need a different routing arrangement.

The base floor and the four case-screw wells remain closed. The battery and
case hardware positions are unchanged. The front PCB seat moves 4 mm inward
along X to clear the cable channel.

## Hardware and assembly

- Four M2 × 8 mm nylon case screws and two M2 × 8 mm nylon midframe screws.
- Six heat-set inserts, outside diameter 3 mm and length 3.2 mm.
- Printed insert pilots are 2.7 mm with a 3.1 mm entry. Verify the fit with your
  insert and material before heat-setting all six. Fit inserts with the battery
  and electronics removed.
- The separate PCB mounting pilot remains 1.2 mm for a provisional M1.6 screw;
  it is not one of the six M2 insert mounts.
- Screen retention, the button strip anchors, and PCB seating still need the
  physical fit check described in the parent README.

## Export checks

All four final revision 17 files are watertight single closed-component meshes
with consistent winding and positive volume. Checks found no degenerate or
duplicate triangles, boundary edges, or nonmanifold edges. Each part has
minimum X, Y and Z at zero. `export-manifest.json` records measured dimensions,
orientation transforms, source and mesh hashes, and per-part check results.

The base and button strip match their validated revision 16 meshes exactly.
Their retained cleanup retriangulates five zero-area base faces and removes
342 zero-area button-strip faces, without changing dimensions. Mesh validation
does not establish supplier acceptance, physical fit, or slicer support settings.

The revision 17 browser preview was inspected in the alignment-key and display-seat
views without reported console warnings or errors. That visual check does not
establish hardware fit. The manufacturer remains undecided; Protolabs was
ruled out by the user on price.
